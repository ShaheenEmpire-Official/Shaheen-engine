    'use strict';

    // SHAHEEN SEARCH v1 — local-only search. No external API calls are made.
    const STORAGE_KEY = 'shaheen-search-custom-v1';
    const MAX_CUSTOM_ENTRIES = 1000;
    const MAX_IMPORT_BYTES = 2 * 1024 * 1024;

    const STARTER_INDEX = [
      {id:'s01',title:'MDN Web Docs',url:'https://developer.mozilla.org/',description:'Reference documentation and learning guides for HTML, CSS, JavaScript, and web platform technologies.',type:'web',tags:['web development','html','css','javascript','programming','coding'],date:'2026-01-10'},
      {id:'s02',title:'Khan Academy',url:'https://www.khanacademy.org/',description:'Free lessons and practice in mathematics, science, computing, economics, and other school subjects.',type:'web',tags:['math','mathematics','science','learning','education','school','गणित','ریاضی','विज्ञान','سائنس','تعلیم'],date:'2026-01-10'},
      {id:'s03',title:'NASA Science',url:'https://science.nasa.gov/',description:'NASA science information about Earth, the solar system, the universe, missions, and discoveries.',type:'web',tags:['space','astronomy','planets','earth','science','nasa','अंतरिक्ष','خلاء','سیارہ','ग्रह','کائنات'],date:'2026-01-10'},
      {id:'s04',title:'World Health Organization',url:'https://www.who.int/',description:'Public health information, health topics, guidance, and updates from the World Health Organization.',type:'web',tags:['health','public health','medicine','wellbeing','who','स्वास्थ्य','صحت','طبی','صحت عامہ'],date:'2026-01-10'},
      {id:'s05',title:'Wikimedia Commons',url:'https://commons.wikimedia.org/',description:'A media repository containing freely usable educational photographs, audio, video, and other media.',type:'images',tags:['images','photos','pictures','media','commons','visuals'],date:'2026-01-10'},
      {id:'s06',title:'Wikimedia Commons — Video',url:'https://commons.wikimedia.org/wiki/Category:Videos',description:'A category page for video files hosted by Wikimedia Commons.',type:'videos',tags:['video','videos','media','learning'],date:'2026-01-10'},
      {id:'s07',title:'arXiv',url:'https://arxiv.org/',description:'Open access repository for research papers in fields including physics, mathematics, computer science, and more.',type:'documents',tags:['research','papers','academic','science','physics','math','computer science'],date:'2026-01-10'},
      {id:'s08',title:'Project Gutenberg',url:'https://www.gutenberg.org/',description:'A library of free electronic books, especially public-domain literature.',type:'documents',tags:['books','ebooks','literature','reading','history','documents'],date:'2026-01-10'},
      {id:'s09',title:'BBC News',url:'https://www.bbc.com/news',description:'International and regional news coverage. Check the publisher for the latest reporting and updates.',type:'news',tags:['news','world news','current affairs','international','समाचार','خبریں','دنیا','दुनिया'],date:'2026-01-10'},
      {id:'s10',title:'Reuters',url:'https://www.reuters.com/',description:'International news reporting about world events, business, markets, and other topics.',type:'news',tags:['news','world','business','reporting','current affairs'],date:'2026-01-10'},
      {id:'s11',title:'GitHub',url:'https://github.com/',description:'A platform for hosting code repositories, collaborating on software, and sharing open-source projects.',type:'web',tags:['coding','programming','software','developer','repositories','github'],date:'2026-01-10'},
      {id:'s12',title:'Our World in Data',url:'https://ourworldindata.org/',description:'Research and data visualizations on global issues such as health, education, energy, poverty, and population.',type:'documents',tags:['data','statistics','research','global','world','charts'],date:'2026-01-10'},
      {id:'s13',title:'Britannica',url:'https://www.britannica.com/',description:'An encyclopedia with reference articles covering history, science, geography, culture, and people.',type:'web',tags:['encyclopedia','facts','history','geography','science','knowledge'],date:'2026-01-10'},
      {id:'s14',title:'OpenStax',url:'https://openstax.org/',description:'Free, peer-reviewed, openly licensed textbooks for school, college, and independent learning.',type:'documents',tags:['textbooks','books','math','science','education','study'],date:'2026-01-10'},
      {id:'s15',title:'The Internet Archive',url:'https://archive.org/',description:'A digital library offering access to archived webpages, books, audio, video, and other digital materials.',type:'web',tags:['archive','books','videos','audio','history','documents'],date:'2026-01-10'}
    ];

    const $ = (selector) => document.querySelector(selector);
    const $$ = (selector) => [...document.querySelectorAll(selector)];
    const state = {query:'',type:'all',sort:'relevance',lastResults:[],custom:loadCustom()};

    function loadCustom() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return [];
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed.filter(validRecord).slice(0,MAX_CUSTOM_ENTRIES) : [];
      } catch (error) { return []; }
    }
    function saveCustom() {
      try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state.custom)); return true; }
      catch (error) { showToast('Could not save. Browser storage may be full or disabled.'); return false; }
    }
    function validRecord(item) {
      if (!item || typeof item !== 'object') return false;
      if (typeof item.title !== 'string' || !item.title.trim() || item.title.length > 100) return false;
      if (typeof item.url !== 'string' || item.url.length > 500) return false;
      try { const u = new URL(item.url); if (u.protocol !== 'https:') return false; }
      catch (error) { return false; }
      return ['web','news','images','videos','documents'].includes(item.type) &&
        typeof item.description === 'string' && item.description.length <= 500 &&
        Array.isArray(item.tags) && item.tags.length <= 30 &&
        item.tags.every(tag => typeof tag === 'string' && tag.length <= 40);
    }
    function allRecords() { return [...STARTER_INDEX, ...state.custom]; }
    function normalize(value) {
      return String(value || '').toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}\s-]/gu,' ').replace(/\s+/g,' ').trim();
    }
    function tokens(value) { return normalize(value).split(' ').filter(word => word.length > 1); }
    function scoreRecord(record, query) {
      const q = normalize(query);
      const words = tokens(query);
      if (!q || words.length === 0) return 0;
      const title = normalize(record.title);
      const desc = normalize(record.description);
      const tags = normalize((record.tags || []).join(' '));
      const url = normalize(record.url);
      let score = 0;
      if (title === q) score += 100;
      if (title.includes(q)) score += 45;
      if (tags.includes(q)) score += 25;
      if (desc.includes(q)) score += 12;
      for (const word of words) {
        if (title.split(' ').some(part => part === word)) score += 12;
        else if (title.split(' ').some(part => part.startsWith(word))) score += 7;
        if (tags.split(' ').some(part => part === word)) score += 9;
        else if (tags.includes(word)) score += 4;
        if (desc.includes(word)) score += 3;
        if (url.includes(word)) score += 1;
      }
      const matched = words.filter(word => `${title} ${desc} ${tags} ${url}`.includes(word)).length;
      score += matched * 2;
      if (matched === words.length) score += 8;
      return score;
    }
    function getResults() {
      const query = state.query;
      let items = allRecords().map(record => ({record,score:scoreRecord(record,query)})).filter(item => item.score > 0);
      if (state.type !== 'all') items = items.filter(item => item.record.type === state.type);
      if (state.sort === 'title') items.sort((a,b) => a.record.title.localeCompare(b.record.title));
      else if (state.sort === 'newest') items.sort((a,b) => String(b.record.date || '').localeCompare(String(a.record.date || '')));
      else items.sort((a,b) => b.score - a.score || a.record.title.localeCompare(b.record.title));
      return items;
    }
    function escapeHTML(value) {
      return String(value).replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
    }
    function hostOf(value) {
      try { return new URL(value).hostname; } catch (error) { return value; }
    }
    function renderResults() {
      const target = $('#resultsList');
      const count = $('#resultCount');
      if (!state.query) {
        count.textContent = 'START WITH A SEARCH';
        target.innerHTML = '<div class="empty"><h2>YOUR SEARCH STARTS HERE.</h2><p>Try “space”, “learn coding”, “health”, or add your own website entry. Results come from the local index in this browser.</p></div>';
        state.lastResults = [];
        $('#researchBox').classList.add('hidden');
        return;
      }
      const results = getResults();
      state.lastResults = results;
      count.textContent = `${results.length} LOCAL RESULT${results.length === 1 ? '' : 'S'} FOR “${state.query.toUpperCase()}”`;
      if (!results.length) {
        target.innerHTML = `<div class="empty"><h2>NO MATCH IN THIS INDEX.</h2><p>That does not mean the page does not exist on the internet. This browser only searches the starter catalog and links you have added. Add a source or import a larger JSON index.</p><p style="margin-top:15px"><button class="solid-btn" type="button" id="emptyAdd">+ ADD A SOURCE</button></p></div>`;
        $('#emptyAdd').addEventListener('click',openSourceDialog);
        $('#researchBox').classList.add('hidden');
        return;
      }
      target.innerHTML = results.map(({record,score},index) => `
        <article class="result-card">
          <div class="result-kicker"><span>${escapeHTML(record.type)} · ${record.custom ? 'YOUR SOURCE' : 'STARTER INDEX'}</span><span>MATCH ${index + 1}</span></div>
          <a class="result-title" href="${escapeHTML(record.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(record.title)}</a>
          <div class="result-url">${escapeHTML(hostOf(record.url))}</div>
          <p class="result-desc">${escapeHTML(record.description || 'No description provided.')}</p>
          <div class="result-tags">${(record.tags || []).slice(0,5).map(tag => `<span class="tag">${escapeHTML(tag)}</span>`).join('')}</div>
        </article>`).join('');
      if (!$('#researchBox').classList.contains('hidden')) renderResearch();
    }
    function renderResearch() {
      const box = $('#researchBox');
      const results = getResults().slice(0,5);
      if (!state.query || !results.length) { box.classList.add('hidden'); return; }
      const categories = [...new Set(results.map(item => item.record.type))];
      box.classList.remove('hidden');
      box.innerHTML = `<h2>LOCAL RESEARCH SNAPSHOT</h2><p>This is a simple summary of matching entries in your local index—not an AI-generated answer and not a live web investigation. Your search matched ${getResults().length} indexed item(s), across ${categories.length} content type(s). Open the sources below to verify details and read the original material.</p><ol class="research-sources">${results.map(item => `<li><a href="${escapeHTML(item.record.url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(item.record.title)}</a> — ${escapeHTML(item.record.description)}</li>`).join('')}</ol>`;
    }
    function showToast(message) {
      const toast = $('#toast'); toast.textContent = message; toast.classList.add('show');
      clearTimeout(showToast.timer); showToast.timer = setTimeout(() => toast.classList.remove('show'),2600);
    }
    function runSearch() {
      state.query = $('#query').value.trim().slice(0,180);
      renderResults();
    }
    function setType(type) {
      state.type = type;
      $$('.tab').forEach(button => button.setAttribute('aria-pressed',String(button.dataset.type === type)));
      renderResults();
    }
    function openSourceDialog() { $('#sourceDialog').showModal(); }
    function closeDialog(id) { const dialog = $(id); if (dialog.open) dialog.close(); }
    function createId() { return 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
    function addSource(event) {
      event.preventDefault();
      const form = event.currentTarget;
      const data = new FormData(form);
      const rawUrl = String(data.get('url') || '').trim();
      let safeUrl;
      try { safeUrl = new URL(rawUrl); } catch (error) { showToast('Enter a valid HTTPS URL.'); return; }
      if (safeUrl.protocol !== 'https:') { showToast('Only HTTPS website links are allowed.'); return; }
      if (state.custom.length >= MAX_CUSTOM_ENTRIES) { showToast('Your index reached the 1,000 entry limit.'); return; }
      const record = {
        id:createId(), title:String(data.get('title') || '').trim(), url:safeUrl.href,
        description:String(data.get('description') || '').trim(), type:String(data.get('type') || 'web'),
        tags:String(data.get('tags') || '').split(',').map(tag => tag.trim()).filter(Boolean).slice(0,30),
        date:new Date().toISOString().slice(0,10), custom:true
      };
      if (!validRecord(record)) { showToast('Please check the source details.'); return; }
      state.custom.unshift(record);
      if (!saveCustom()) { state.custom.shift(); return; }
      form.reset(); closeDialog('#sourceDialog'); renderResults(); renderManageList(); showToast('Source saved on this device.');
    }
    function renderManageList() {
      const target = $('#manageList');
      if (!state.custom.length) { target.innerHTML = '<div class="manage-row">No custom sources saved yet.</div>'; return; }
      target.innerHTML = state.custom.map(record => `<div class="manage-row"><span><strong>${escapeHTML(record.title)}</strong><br>${escapeHTML(hostOf(record.url))}</span><button type="button" data-remove="${escapeHTML(record.id)}">DELETE</button></div>`).join('');
      target.querySelectorAll('[data-remove]').forEach(button => button.addEventListener('click',() => {
        const id = button.dataset.remove; state.custom = state.custom.filter(record => record.id !== id); saveCustom(); renderManageList(); renderResults(); showToast('Source deleted.');
      }));
    }
    function openManageDialog() { renderManageList(); $('#manageDialog').showModal(); }
    function exportIndex() {
      const payload = {app:'SHAHEEN SEARCH',formatVersion:1,exportedAt:new Date().toISOString(),entries:state.custom};
      const blob = new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
      const url = URL.createObjectURL(blob); const anchor = document.createElement('a');
      anchor.href = url; anchor.download = 'shaheen-search-my-index.json'; document.body.appendChild(anchor); anchor.click(); anchor.remove(); URL.revokeObjectURL(url);
      showToast('Your custom index backup was exported.');
    }
    async function importIndex(file) {
      if (!file) return;
      if (file.size > MAX_IMPORT_BYTES) { showToast('Import file must be 2 MB or smaller.'); return; }
      try {
        const parsed = JSON.parse(await file.text());
        const entries = Array.isArray(parsed) ? parsed : parsed.entries;
        if (!Array.isArray(entries)) throw new Error('Invalid file');
        const accepted = entries.filter(validRecord).slice(0,MAX_CUSTOM_ENTRIES);
        const existingUrls = new Set(state.custom.map(record => record.url));
        const merged = [...state.custom];
        for (const entry of accepted) {
          if (!existingUrls.has(entry.url) && merged.length < MAX_CUSTOM_ENTRIES) {
            merged.push({...entry,id:createId(),custom:true}); existingUrls.add(entry.url);
          }
        }
        const old = state.custom; state.custom = merged;
        if (!saveCustom()) { state.custom = old; return; }
        renderManageList(); renderResults(); showToast(`${accepted.length} valid entry/entries found; duplicates skipped.`);
      } catch (error) { showToast('Could not read this JSON index file.'); }
      $('#importFile').value = '';
    }

    $('#searchForm').addEventListener('submit',event => { event.preventDefault(); runSearch(); });
    $('#query').addEventListener('input',() => { clearTimeout(runSearch.timer); runSearch.timer = setTimeout(runSearch,180); });
    $$('.tab').forEach(button => button.addEventListener('click',() => setType(button.dataset.type)));
    $('#sortSelect').addEventListener('change',event => { state.sort = event.target.value; renderResults(); });
    $('#researchBtn').addEventListener('click',() => { if (!state.query) { showToast('Enter a search first.'); $('#query').focus(); return; } $('#researchBox').classList.toggle('hidden'); renderResearch(); });
    $('#addBtn').addEventListener('click',openSourceDialog);
    $('#manageTop').addEventListener('click',openManageDialog);
    $('#manageSide').addEventListener('click',openManageDialog);
    $('#exportBtn').addEventListener('click',exportIndex);
    $('#exportManage').addEventListener('click',exportIndex);
    $('#sourceForm').addEventListener('submit',addSource);
    $('#closeSource').addEventListener('click',() => closeDialog('#sourceDialog'));
    $('#cancelSource').addEventListener('click',() => closeDialog('#sourceDialog'));
    $('#closeManage').addEventListener('click',() => closeDialog('#manageDialog'));
    $('#importBtn').addEventListener('click',() => $('#importFile').click());
    $('#importFile').addEventListener('change',event => importIndex(event.target.files[0]));
    $('#clearCustom').addEventListener('click',() => {
      if (!state.custom.length) { showToast('Your custom index is already empty.'); return; }
      if (!confirm('Delete all custom entries saved in this browser? This cannot be undone unless you exported a backup.')) return;
      state.custom = []; saveCustom(); renderManageList(); renderResults(); showToast('All custom entries deleted.');
    });
    $('#privacyBtn').addEventListener('click',() => $('#privacyDialog').showModal());
    $('#closePrivacy').addEventListener('click',() => closeDialog('#privacyDialog'));
    $('#closePrivacyBottom').addEventListener('click',() => closeDialog('#privacyDialog'));

    // Register the first-party offline shell. The service worker only caches this app's own files.
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('./sw.js').then(() => { $('#offlineStatus').textContent = 'OFFLINE APP SHELL ENABLED'; }).catch(() => { $('#offlineStatus').textContent = 'OFFLINE CACHE UNAVAILABLE'; });
    } else {
      $('#offlineStatus').textContent = 'OPEN ONLINE ONCE TO ENABLE APP CACHING';
    }
    if (navigator.onLine) $('#connectionStatus').textContent = 'LOCAL INDEX · ONLINE';
    else $('#connectionStatus').textContent = 'LOCAL INDEX · OFFLINE';
    window.addEventListener('online',() => $('#connectionStatus').textContent = 'LOCAL INDEX · ONLINE');
    window.addEventListener('offline',() => $('#connectionStatus').textContent = 'LOCAL INDEX · OFFLINE');

    // Prevent accidental form submissions from doing a network navigation.
    renderManageList();
