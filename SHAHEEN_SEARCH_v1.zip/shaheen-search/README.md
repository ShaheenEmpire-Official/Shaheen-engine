# SHAHEEN SEARCH — v1

A lightweight, monochrome, local-index search app built with **HTML, CSS, and vanilla JavaScript**. It uses no external search API, analytics, third-party scripts, remote fonts, or remote images. The app uses a restrictive same-origin Content Security Policy.

## What works in this version

- Search the bundled starter catalog with a local relevance-ranking algorithm.
- Filter results by Web, News, Images, Videos, and Documents.
- Generate a transparent research snapshot from matching local records (not an AI model).
- Add HTTPS links to your personal index.
- Save custom entries in the current browser using localStorage.
- Export and import a JSON backup of custom entries.
- Delete individual custom entries or clear the custom index.
- Cache the app shell for offline reopening after the first successful online visit.
- Responsive, text-first interface using black and white only.

## Important limitation

This is **not yet a full-web search engine**. A static website running on GitHub Pages cannot independently crawl the entire internet or retrieve live pages from arbitrary domains. Browser security (including cross-origin restrictions) also prevents a static page from freely reading every website. With no external search source and no crawler/backend, search is limited to the bundled catalog and records the user adds. Adding a source saves its metadata; it does not crawl the target website.

A real independent global search engine would need a separately hosted crawler, a database/search index, scheduled recrawling, abuse controls, and substantial compute/storage. Those can be written as our own software without a third-party search API, but they cannot run inside GitHub Pages alone.

## Publish using GitHub Pages on mobile

1. Create a GitHub repository, for example `shaheen-search`.
2. Upload **all six files** from this folder to the repository root: `index.html`, `styles.css`, `app.js`, `sw.js`, `manifest.webmanifest`, and `README.md`.
3. In the repository, open **Settings → Pages**.
4. Under the build/deployment source, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/ (root)`, then save.
6. Open the Pages URL after deployment. Visit once while online, then refresh once so the offline shell can be installed.

## Privacy notes

- Search queries are processed in the browser and are not sent to a search API by this code.
- Search history is not stored.
- Custom index entries are saved in localStorage on the device/browser where they were added.
- When a user opens an external result, that external website receives the user's normal browser request and follows its own privacy practices.
- GitHub Pages or another hosting provider may process ordinary connection/security logs. Do not describe a hosted website as having literally zero infrastructure logging.
- This project has not undergone an independent security audit. Do not store passwords, secrets, or sensitive personal data in it.

## Run locally

Open `index.html` in a browser for basic local search. Service-worker offline caching requires serving the files from localhost or HTTPS; it does not work from a `file://` URL.
